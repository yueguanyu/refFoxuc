USE QPTreasureDB
GO

-----------------------------------------------------------------------------------------------------------

INSERT [GameColumnItem] ([SortID],[ColumnName],[ColumnWidth],[DataDescribe]) VALUES ( 1,'�ǳ�',100,3)
INSERT [GameColumnItem] ([SortID],[ColumnName],[ColumnWidth],[DataDescribe]) VALUES ( 2,'ID',60,1)
INSERT [GameColumnItem] ([SortID],[ColumnName],[ColumnWidth],[DataDescribe]) VALUES ( 3,'��Ϸ��',60,30)
INSERT [GameColumnItem] ([SortID],[ColumnName],[ColumnWidth],[DataDescribe]) VALUES ( 4,'����',40,20)
INSERT [GameColumnItem] ([SortID],[ColumnName],[ColumnWidth],[DataDescribe]) VALUES ( 5,'����',85,44)
INSERT [GameColumnItem] ([SortID],[ColumnName],[ColumnWidth],[DataDescribe]) VALUES ( 6,'����ֵ',85,33)
INSERT [GameColumnItem] ([SortID],[ColumnName],[ColumnWidth],[DataDescribe]) VALUES ( 7,'����ֵ',85,34)
INSERT [GameColumnItem] ([SortID],[ColumnName],[ColumnWidth],[DataDescribe]) VALUES ( 8,'����',60,32)
INSERT [GameColumnItem] ([SortID],[ColumnName],[ColumnWidth],[DataDescribe]) VALUES ( 9,'ʤ��',60,40)
INSERT [GameColumnItem] ([SortID],[ColumnName],[ColumnWidth],[DataDescribe]) VALUES ( 10,'����',60,43)
INSERT [GameColumnItem] ([SortID],[ColumnName],[ColumnWidth],[DataDescribe]) VALUES ( 11,'�ܾ�',60,39)
INSERT [GameColumnItem] ([SortID],[ColumnName],[ColumnWidth],[DataDescribe]) VALUES ( 12,'Ӯ��',60,35)
INSERT [GameColumnItem] ([SortID],[ColumnName],[ColumnWidth],[DataDescribe]) VALUES ( 13,'���',60,36)
INSERT [GameColumnItem] ([SortID],[ColumnName],[ColumnWidth],[DataDescribe]) VALUES ( 14,'�;�',60,37)
INSERT [GameColumnItem] ([SortID],[ColumnName],[ColumnWidth],[DataDescribe]) VALUES ( 15,'�Ӿ�',60,38)
INSERT [GameColumnItem] ([SortID],[ColumnName],[ColumnWidth],[DataDescribe]) VALUES ( 16,'����',85,11)
INSERT [GameColumnItem] ([SortID],[ColumnName],[ColumnWidth],[DataDescribe]) VALUES ( 17,'ǩ��',150,12)